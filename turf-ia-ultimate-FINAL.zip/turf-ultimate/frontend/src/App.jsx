import { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

const API = process.env.REACT_APP_API_URL || "http://localhost:8000";
const C = {
  bg:"#050505",s1:"#0d0d0d",s2:"#131313",border:"#1a1a1a",b2:"#222",
  green:"#00e87a",red:"#ff3b3b",yellow:"#ffc800",blue:"#3b8fff",purple:"#9b59ff",orange:"#ff8c42",
  white:"#ececec",grey:"#444",
  mono:"'JetBrains Mono',monospace",display:"'Bebas Neue',sans-serif",body:"'Barlow',sans-serif",
};
const call = async (ep, opts={}) => {
  const r = await fetch(`${API}${ep}`, {headers:{"Content-Type":"application/json"},...opts});
  if(!r.ok) throw new Error(r.status);
  return r.json();
};

export default function App() {
  const [tab,setTab] = useState("dashboard");
  const [stats,setStats] = useState(null);
  const [history,setHistory] = useState([]);
  const [bankrollHist,setBankrollHist] = useState([]);
  const [memory,setMemory] = useState(null);
  const [ok,setOk] = useState(false);
  // Analyse
  const [date,setDate] = useState(new Date().toISOString().split("T")[0]);
  const [prog,setProg] = useState(null);
  const [selR,setSelR] = useState(null);
  const [selC,setSelC] = useState(null);
  const [result,setResult] = useState(null);
  const [loading,setLoading] = useState(false);

  useEffect(()=>{load();},[]);

  const load = async () => {
    try {
      await call("/health"); setOk(true);
      const [s,h,b,m] = await Promise.all([
        call("/api/stats"), call("/api/history?limit=40"),
        call("/api/bankroll"), call("/api/memory")
      ]);
      setStats(s); setHistory(h); setBankrollHist(b); setMemory(m);
    } catch { setOk(false); }
  };

  const loadProg = async () => {
    setLoading(true);
    try { const d=await call(`/api/programme/${date}`); setProg(d); setSelR(null); setSelC(null); setResult(null); }
    catch(e){alert("Erreur PMU: "+e.message);}
    finally{setLoading(false);}
  };

  const decide = async () => {
    if(!selC||!selR) return;
    setLoading(true);
    try {
      const r = await call("/api/decide",{method:"POST",body:JSON.stringify({
        date,reunion:selR.numOfficiel,course_num:selC.numOrdre,course:selC
      })});
      setResult(r);
    } catch(e){alert("Erreur: "+e.message);}
    finally{setLoading(false);}
  };

  const reunions = prog?.programme?.reunions||[];
  const initial = stats?.bankroll_initiale||500;
  const current = stats?.bankroll_actuelle||500;
  const pnl = current - initial;
  const bankData = [...bankrollHist].reverse().map((b,i)=>({i, montant: parseFloat(b.montant||0).toFixed(2)}));

  return (
    <div style={{background:C.bg,minHeight:"100vh",color:C.white,fontFamily:C.body}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=JetBrains+Mono:wght@400;600&family=Barlow:wght@300;400;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#2a2a2a}
        input,select{color-scheme:dark}
        @keyframes fadeIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes glow{0%,100%{box-shadow:0 0 8px #00e87a33}50%{box-shadow:0 0 20px #00e87a66}}
        .fade{animation:fadeIn .3s ease}
      `}</style>

      {/* HEADER */}
      <div style={{background:C.s1,borderBottom:`1px solid ${C.border}`,padding:"0 20px",height:58,display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:100}}>
        <div style={{fontFamily:C.display,fontSize:"1.8rem",letterSpacing:8,color:C.green,textShadow:`0 0 20px ${C.green}44`}}>
          TURF<span style={{color:"#222",fontSize:"1rem"}}> IA ULTIMATE</span>
        </div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          {stats && <>
            <Chip c={pnl>=0?C.green:C.red} label={`${pnl>=0?"+":""}${pnl.toFixed(2)}€`}/>
            <Chip c={C.yellow} label={`${stats.win_rate||0}% wins`}/>
            <Chip c={C.blue} label={`${current.toFixed(0)}€`}/>
          </>}
          <Chip c={ok?C.green:C.red} label={ok?"● LIVE":"● OFF"}/>
        </div>
      </div>

      {/* TABS */}
      <div style={{display:"flex",borderBottom:`1px solid ${C.border}`,background:C.s1,padding:"0 20px",gap:4,overflowX:"auto"}}>
        {[["dashboard","📊 DASHBOARD"],["decide","🧠 CLAUDE DÉCIDE"],["history","📋 DÉCISIONS"],["memory","💾 MÉMOIRE IA"]].map(([id,l])=>(
          <button key={id} onClick={()=>{setTab(id);if(id==="dashboard")load();}}
            style={{fontFamily:C.mono,fontSize:".72rem",letterSpacing:2,padding:"12px 16px",cursor:"pointer",border:"none",background:"none",color:tab===id?C.green:C.grey,borderBottom:tab===id?`2px solid ${C.green}`:"2px solid transparent",whiteSpace:"nowrap"}}>
            {l}
          </button>
        ))}
      </div>

      <div style={{maxWidth:1000,margin:"0 auto",padding:"20px 16px 80px"}}>

        {/* ════ DASHBOARD ════ */}
        {tab==="dashboard" && <div className="fade">
          {/* KPIs */}
          {stats && <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:12,marginBottom:24}}>
            <KPI label="BANKROLL" value={`${current.toFixed(2)}€`} color={C.blue} sub={`Initial: ${initial}€`}/>
            <KPI label="P&L TOTAL" value={`${pnl>=0?"+":""}${pnl.toFixed(2)}€`} color={pnl>=0?C.green:C.red} sub={`ROI: ${stats.roi||0}%`}/>
            <KPI label="WIN RATE" value={`${stats.win_rate||0}%`} color={C.yellow} sub={`${stats.wins||0}/${stats.jouees||0} jouées`}/>
            <KPI label="PASSÉES" value={stats.passees||0} color={C.purple} sub="Courses filtrées"/>
          </div>}

          {/* Courbe bankroll */}
          {bankData.length > 1 && <Card title="ÉVOLUTION BANKROLL">
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={bankData}>
                <XAxis dataKey="i" hide/>
                <YAxis domain={['auto','auto']} tick={{fill:"#555",fontSize:10}} width={50}/>
                <Tooltip contentStyle={{background:C.s2,border:`1px solid ${C.b2}`,fontFamily:C.mono,fontSize:11}} formatter={v=>[`${parseFloat(v).toFixed(2)}€`]}/>
                <ReferenceLine y={initial} stroke="#333" strokeDasharray="4 4"/>
                <Line type="monotone" dataKey="montant" stroke={C.green} dot={false} strokeWidth={2}/>
              </LineChart>
            </ResponsiveContainer>
          </Card>}

          {/* Dernières décisions */}
          <Card title="DERNIÈRES DÉCISIONS">
            {history.slice(0,8).map((h,i)=>(
              <div key={i} style={{display:"flex",gap:10,padding:"8px 0",borderBottom:`1px solid ${C.border}`,alignItems:"center"}}>
                <span style={{fontSize:"1.1rem",minWidth:24}}>{h.decision==='PASSER'?"⏭️":h.success?"✅":"❌"}</span>
                <span style={{flex:1,fontSize:".82rem",color:h.decision==='PASSER'?"#555":C.white}}>{h.course_name||"?"}</span>
                {h.decision==='JOUER' && <>
                  <span style={{fontFamily:C.mono,fontSize:".65rem",color:"#666"}}>N°{h.pick1_num}&{h.pick2_num}</span>
                  <span style={{fontFamily:C.mono,fontSize:".7rem",color:h.gain_perte>=0?C.green:C.red,minWidth:60,textAlign:"right"}}>{h.gain_perte!=null?`${h.gain_perte>=0?"+":""}${h.gain_perte.toFixed(2)}€`:""}</span>
                </>}
                {h.decision==='PASSER' && <span style={{fontFamily:C.mono,fontSize:".6rem",color:"#444",maxWidth:200,textAlign:"right"}}>{(h.raison_passer||"").slice(0,50)}</span>}
              </div>
            ))}
          </Card>
        </div>}

        {/* ════ CLAUDE DÉCIDE ════ */}
        {tab==="decide" && <div className="fade">
          <div style={{display:"flex",gap:10,marginBottom:20}}>
            <input type="date" value={date} onChange={e=>setDate(e.target.value)}
              style={{flex:1,background:C.s1,border:`1px solid ${C.b2}`,color:C.white,padding:"10px 14px",fontFamily:C.mono,fontSize:".8rem",borderRadius:4,outline:"none"}}/>
            <Btn onClick={loadProg} loading={loading}>CHARGER PMU</Btn>
          </div>

          {reunions.length>0 && <>
            <Label>RÉUNIONS</Label>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:16}}>
              {reunions.map(r=>(
                <button key={r.numOfficiel} onClick={()=>{setSelR(r);setSelC(null);setResult(null);}}
                  style={{background:selR?.numOfficiel===r.numOfficiel?"rgba(0,232,122,.06)":C.s1,border:`1px solid ${selR?.numOfficiel===r.numOfficiel?C.green:C.border}`,color:selR?.numOfficiel===r.numOfficiel?C.green:C.grey,padding:"7px 14px",borderRadius:4,cursor:"pointer",fontFamily:C.mono,fontSize:".7rem"}}>
                  <b>R{r.numOfficiel}</b> {r.hippodrome?.libelleCourt||""}
                </button>
              ))}
            </div>
          </>}

          {selR?.courses?.length>0 && <>
            <Label>COURSES</Label>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:20}}>
              {selR.courses.map(c=>(
                <button key={c.numOrdre} onClick={()=>{setSelC(c);setResult(null);}}
                  style={{background:selC?.numOrdre===c.numOrdre?"rgba(59,143,255,.06)":C.s1,border:`1px solid ${selC?.numOrdre===c.numOrdre?C.blue:C.border}`,color:selC?.numOrdre===c.numOrdre?C.blue:"#666",padding:"8px 12px",borderRadius:4,cursor:"pointer",fontFamily:C.mono,fontSize:".7rem",textAlign:"left",minWidth:65}}>
                  <div style={{fontFamily:C.display,fontSize:"1.1rem"}}>C{c.numOrdre}</div>
                  <div style={{fontSize:".58rem",color:"#555"}}>{c.heureDepart?new Date(c.heureDepart).toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"}):""}</div>
                </button>
              ))}
            </div>
          </>}

          {selC && !result && (
            <div style={{marginBottom:20}}>
              <Btn onClick={decide} loading={loading} big>🧠 CLAUDE DÉCIDE</Btn>
              <div style={{fontFamily:C.mono,fontSize:".62rem",color:"#444",marginTop:8}}>
                {selC.libelle} | {selC.discipline} {selC.distance}m | Claude analysera tout et décidera seul
              </div>
            </div>
          )}

          {result && <DecisionResult result={result}/>}
        </div>}

        {/* ════ HISTORIQUE DÉCISIONS ════ */}
        {tab==="history" && <div className="fade">
          <div style={{fontFamily:C.display,fontSize:"1.4rem",letterSpacing:4,marginBottom:20}}>TOUTES LES DÉCISIONS</div>
          {history.map((h,i)=>(
            <div key={i} style={{background:C.s1,border:`1px solid ${h.decision==='JOUER'?(h.success?C.green:h.pick1_in_top4||h.pick2_in_top4?C.yellow:C.red):C.border}`,borderRadius:6,padding:"14px 16px",marginBottom:10}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <div>
                  <span style={{fontWeight:700,fontSize:".9rem"}}>{h.course_name}</span>
                  <span style={{fontFamily:C.mono,fontSize:".6rem",color:"#555",marginLeft:12}}>{h.date} · {h.discipline}</span>
                </div>
                <div style={{display:"flex",gap:8,alignItems:"center"}}>
                  {h.decision==='JOUER' && h.gain_perte!=null && (
                    <span style={{fontFamily:C.mono,fontSize:".75rem",color:h.gain_perte>=0?C.green:C.red,fontWeight:700}}>
                      {h.gain_perte>=0?"+":""}{h.gain_perte.toFixed(2)}€
                    </span>
                  )}
                  <span style={{fontSize:"1.2rem"}}>{h.decision==='PASSER'?"⏭️":h.success?"✅":h.pick1_in_top4||h.pick2_in_top4?"⚠️":"❌"}</span>
                </div>
              </div>
              {h.decision==='JOUER' ? (
                <div style={{fontFamily:C.mono,fontSize:".65rem",color:"#666"}}>
                  N°{h.pick1_num} {h.pick1_name} ({(h.pick1_prob||0)*100|0}%) & N°{h.pick2_num} {h.pick2_name} ({(h.pick2_prob||0)*100|0}%) | Mise: {h.mise_recommandee}€ | Edge: {((h.edge_estime||0)*100).toFixed(1)}%
                </div>
              ) : (
                <div style={{fontFamily:C.mono,fontSize:".65rem",color:"#555",fontStyle:"italic"}}>{h.raison_passer}</div>
              )}
              {h.raisonnement && <div style={{fontFamily:C.mono,fontSize:".62rem",color:"#444",marginTop:8,lineHeight:1.7,borderTop:`1px solid #111`,paddingTop:8}}>{h.raisonnement.slice(0,250)}{h.raisonnement.length>250?"…":""}</div>}
            </div>
          ))}
        </div>}

        {/* ════ MÉMOIRE IA ════ */}
        {tab==="memory" && <div className="fade">
          <div style={{fontFamily:C.display,fontSize:"1.4rem",letterSpacing:4,marginBottom:20}}>MÉMOIRE STRATÉGIQUE CLAUDE</div>
          {memory && <>
            <Card title="LEÇONS APPRISES">
              {(memory.lessons||[]).length===0
                ? <div style={{fontFamily:C.mono,fontSize:".7rem",color:"#444"}}>Aucune leçon encore — Claude apprend après chaque résultat</div>
                : [...(memory.lessons||[])].reverse().map((l,i)=>(
                  <div key={i} style={{fontFamily:C.mono,fontSize:".72rem",color:C.green,padding:"6px 0",borderBottom:`1px solid ${C.border}`,lineHeight:1.7}}>💡 {l}</div>
                ))}
            </Card>
            <Card title="PATTERNS D'ERREUR IDENTIFIÉS">
              {(memory.pattern_errors||[]).length===0
                ? <div style={{fontFamily:C.mono,fontSize:".7rem",color:"#444"}}>Aucun pattern identifié</div>
                : (memory.pattern_errors||[]).map((e,i)=>(
                  <div key={i} style={{fontFamily:C.mono,fontSize:".72rem",color:C.red,padding:"6px 0",borderBottom:`1px solid ${C.border}`}}>⚠️ {e}</div>
                ))}
            </Card>
            <Card title="STATS">
              <div style={{display:"flex",gap:20,flexWrap:"wrap",fontFamily:C.mono,fontSize:".7rem",color:"#888"}}>
                <span>Décisions totales: <b style={{color:C.white}}>{memory.total_decisions||0}</b></span>
                <span>Jouées: <b style={{color:C.white}}>{memory.total_jouees||0}</b></span>
                <span>Passées: <b style={{color:C.white}}>{memory.total_passees||0}</b></span>
                <span>Win rate: <b style={{color:C.green}}>{((memory.win_rate||0)*100).toFixed(1)}%</b></span>
                <span>ROI: <b style={{color:memory.roi>=0?C.green:C.red}}>{((memory.roi||0)*100).toFixed(1)}%</b></span>
              </div>
            </Card>
          </>}
        </div>}
      </div>
    </div>
  );
}

function DecisionResult({result}) {
  const d = result.decision;
  const isJouer = d.decision === "JOUER";
  return (
    <div className="fade">
      {/* Décision principale */}
      <div style={{background:isJouer?"rgba(0,232,122,.05)":"rgba(255,59,59,.04)",border:`2px solid ${isJouer?C.green:C.red}`,borderRadius:10,padding:24,marginBottom:16,animation:isJouer?"glow 2s infinite":"none"}}>
        <div style={{fontFamily:"'Bebas Neue',sans-serif",fontSize:"2.5rem",letterSpacing:6,color:isJouer?C.green:C.red,marginBottom:16}}>
          {isJouer?"✅ JOUER":"⏭️ PASSER"}
        </div>

        {isJouer ? (<>
          <div style={{display:"flex",gap:16,marginBottom:20,flexWrap:"wrap"}}>
            {[{num:d.pick1_num,nom:d.pick1_name,prob:d.pick1_prob,label:"1er PICK"},{num:d.pick2_num,nom:d.pick2_name,prob:d.pick2_prob,label:"2e PICK"}].map((p,i)=>(
              <div key={i} style={{background:C.s2,borderRadius:8,padding:14,border:`1px solid ${C.b2}`,flex:1,minWidth:140}}>
                <div style={{fontFamily:C.mono,fontSize:".58rem",color:C.grey,marginBottom:6}}>{p.label}</div>
                <div style={{fontFamily:"'Bebas Neue',sans-serif",fontSize:"2rem",color:i===0?C.green:C.yellow}}>N°{p.num}</div>
                <div style={{fontWeight:700,fontSize:".9rem",marginBottom:4}}>{p.nom}</div>
                <div style={{fontFamily:C.mono,fontSize:".65rem",color:"#888"}}>Prob top4: {((p.prob||0)*100).toFixed(1)}%</div>
              </div>
            ))}
          </div>
          <div style={{display:"flex",gap:16,flexWrap:"wrap",marginBottom:16}}>
            <MetaItem label="MISE" value={`${d.mise_recommandee?.toFixed(2)}€`} color={C.yellow}/>
            <MetaItem label="TYPE PARI" value={d.type_pari||"?"} color={C.blue}/>
            <MetaItem label="EDGE" value={`${((d.edge_estime||0)*100).toFixed(1)}%`} color={C.green}/>
            <MetaItem label="COTE ESTIMÉE" value={`${d.cote_estimee?.toFixed(1)||"?"}`} color={C.purple}/>
            <MetaItem label="CONFIANCE" value={`${((d.confiance||0)*100).toFixed(0)}%`} color={C.orange}/>
          </div>
          {d.alerte && <div style={{fontFamily:C.mono,fontSize:".7rem",color:C.red,background:"rgba(255,59,59,.08)",border:"1px solid rgba(255,59,59,.3)",borderRadius:6,padding:"8px 12px",marginBottom:12}}>⚠️ {d.alerte}</div>}
        </>) : (
          <div style={{fontFamily:C.mono,fontSize:".8rem",color:"#888",fontStyle:"italic"}}>{d.raison_passer}</div>
        )}

        {/* Raisonnement */}
        <div style={{marginTop:16,padding:14,background:C.s2,borderRadius:6,border:`1px solid ${C.b2}`}}>
          <div style={{fontFamily:C.mono,fontSize:".58rem",letterSpacing:3,color:C.grey,marginBottom:8}}>🧠 RAISONNEMENT CLAUDE</div>
          <div style={{fontFamily:C.mono,fontSize:".72rem",color:"#aaa",lineHeight:2}}>{d.raisonnement}</div>
        </div>
      </div>

      {/* Signaux */}
      {(d.signaux_positifs?.length>0||d.signaux_negatifs?.length>0) && (
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
          <Card title="✅ SIGNAUX POSITIFS">
            {(d.signaux_positifs||[]).map((s,i)=><div key={i} style={{fontFamily:C.mono,fontSize:".65rem",color:C.green,padding:"4px 0",borderBottom:`1px solid ${C.border}`}}>{s}</div>)}
          </Card>
          <Card title="❌ SIGNAUX NÉGATIFS">
            {(d.signaux_negatifs||[]).map((s,i)=><div key={i} style={{fontFamily:C.mono,fontSize:".65rem",color:C.red,padding:"4px 0",borderBottom:`1px solid ${C.border}`}}>{s}</div>)}
          </Card>
        </div>
      )}

      {/* ML predictions */}
      {result.ml_predictions?.slice(0,6).length > 0 && (
        <Card title="PROBABILITÉS ML">
          {result.ml_predictions.slice(0,6).map((p,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"6px 0",borderBottom:`1px solid #111`}}>
              <span style={{fontFamily:C.display,fontSize:"1.2rem",color:i<2?C.green:"#333",minWidth:28,textAlign:"center"}}>{p.num_pmu}</span>
              <span style={{flex:1,fontSize:".82rem",color:i<2?C.white:"#666"}}>{p.nom}</span>
              <div style={{height:4,background:"#1a1a1a",borderRadius:2,width:100,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${Math.min(p.prob_pct*3,100)}%`,background:i===0?C.green:i===1?C.yellow:"#333"}}/>
              </div>
              <span style={{fontFamily:C.mono,fontSize:".68rem",color:i<2?C.white:"#555",minWidth:40,textAlign:"right"}}>{p.prob_pct}%</span>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

// ── Composants ────────────────────────────────────────────────
const Card = ({title,children}) => (
  <div style={{background:C.s1,border:`1px solid ${C.border}`,borderRadius:8,padding:16,marginBottom:16}}>
    <div style={{fontFamily:C.mono,fontSize:".58rem",letterSpacing:3,color:C.grey,marginBottom:12}}>{title}</div>
    {children}
  </div>
);
const KPI = ({label,value,color,sub}) => (
  <div style={{background:C.s1,border:`1px solid ${C.border}`,borderRadius:8,padding:14,textAlign:"center"}}>
    <div style={{fontFamily:C.mono,fontSize:".58rem",color:"#444",letterSpacing:2,marginBottom:5}}>{label}</div>
    <div style={{fontFamily:C.display,fontSize:"1.9rem",color,lineHeight:1}}>{value}</div>
    <div style={{fontFamily:C.mono,fontSize:".58rem",color:"#555",marginTop:4}}>{sub}</div>
  </div>
);
const Chip = ({c,label}) => <span style={{fontFamily:C.mono,fontSize:".62rem",padding:"3px 9px",borderRadius:20,border:`1px solid ${c}44`,color:c,background:`${c}0a`}}>{label}</span>;
const Label = ({children}) => <div style={{fontFamily:C.mono,fontSize:".6rem",letterSpacing:3,color:C.grey,marginBottom:8}}>{children}</div>;
const MetaItem = ({label,value,color}) => (
  <div style={{background:C.s2,borderRadius:6,padding:"8px 12px",border:`1px solid ${C.b2}`}}>
    <div style={{fontFamily:C.mono,fontSize:".55rem",color:C.grey,letterSpacing:2,marginBottom:3}}>{label}</div>
    <div style={{fontFamily:C.mono,fontSize:".8rem",color,fontWeight:700}}>{value}</div>
  </div>
);
const Btn = ({onClick,children,loading,big}) => (
  <button onClick={onClick} disabled={loading}
    style={{background:loading?"#1a1a1a":C.green,color:loading?"#555":"#000",fontFamily:C.display,letterSpacing:2,fontSize:big?"1.1rem":".85rem",padding:big?"13px 28px":"9px 18px",borderRadius:4,cursor:loading?"not-allowed":"pointer",border:`1px solid ${loading?"#222":C.green}`,display:"inline-flex",alignItems:"center",gap:6}}>
    {loading&&<span style={{width:12,height:12,border:"2px solid #0003",borderTopColor:"#0008",borderRadius:"50%",animation:"spin .6s linear infinite",display:"inline-block"}}/>}
    {children}
  </button>
);

// C colors ref
const C2 = C;
