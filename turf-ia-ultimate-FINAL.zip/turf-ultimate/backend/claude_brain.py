"""
CLAUDE BRAIN — Le cerveau IA qui décide à la place de l'humain
- Analyse complète sans émotion
- Décision JOUER / PASSER avec raisonnement
- Kelly Criterion fractionné pour les mises
- Apprentissage de chaque erreur
- Mémoire des stratégies et patterns
"""
import os, json, math, logging
from typing import List, Dict, Optional, Tuple
import httpx

logger = logging.getLogger(__name__)

KELLY_FRACTION = float(os.getenv("KELLY_FRACTION", "0.25"))
MAX_BET_PCT = float(os.getenv("MAX_BET_PCT", "0.05"))
MIN_EDGE = float(os.getenv("MIN_EDGE", "0.10"))


# ================================================================
# KELLY CRITERION
# ================================================================

def kelly_criterion(prob_win: float, cote: float, bankroll: float,
                     fraction: float = KELLY_FRACTION) -> float:
    """
    Calcule la mise optimale via le critère de Kelly fractionné.
    
    Kelly = (p * b - q) / b
    où p = prob victoire, q = 1-p, b = cote nette
    
    On applique une fraction pour réduire le risque.
    Maximum MAX_BET_PCT de la bankroll.
    """
    if cote <= 1.0 or prob_win <= 0 or prob_win >= 1:
        return 0.0
    b = cote - 1  # Cote nette
    q = 1 - prob_win
    kelly = (prob_win * b - q) / b
    
    if kelly <= 0:
        return 0.0
    
    # Kelly fractionné à 25%
    mise = bankroll * kelly * fraction
    
    # Plafond : max 5% de la bankroll
    max_mise = bankroll * MAX_BET_PCT
    mise = min(mise, max_mise)
    
    # Minimum 2€, arrondi à 0.50€
    if mise < 2.0:
        return 0.0
    
    return round(mise / 0.5) * 0.5


def compute_edge(prob_model: float, cote_marche: float) -> float:
    """
    Edge = probabilité modèle - probabilité implicite marché
    Positif = value bet
    """
    if cote_marche <= 0:
        return 0.0
    prob_marche = 1.0 / cote_marche
    return prob_model - prob_marche


# ================================================================
# CLAUDE BRAIN
# ================================================================

class ClaudeBrain:
    """
    Le cerveau IA principal.
    Claude reçoit TOUTES les données et décide seul.
    """

    def __init__(self):
        self.api_key = os.getenv("ANTHROPIC_API_KEY")
        self.client = httpx.AsyncClient(timeout=60.0)
        self.model = "claude-sonnet-4-20250514"

    async def decide(
        self,
        course_data: Dict,
        partants: List[Dict],
        ml_predictions: List[Dict],
        bankroll: float,
        strategy_memory: Dict,
        recent_history: List[Dict],
    ) -> Dict:
        """
        Décision principale : Claude analyse tout et décide.
        Retourne un dict complet avec décision, raisonnement, mise.
        """
        if not self.api_key:
            return self._fallback_decision(course_data, partants, ml_predictions, bankroll)

        # Construire le prompt complet
        prompt = self._build_decision_prompt(
            course_data, partants, ml_predictions,
            bankroll, strategy_memory, recent_history
        )

        try:
            response = await self._call_claude(prompt)
            decision = self._parse_decision(response, bankroll, ml_predictions, course_data)
            decision['_prompt'] = prompt
            decision['_raw_response'] = response.get('raw_text', '')
            decision['_tokens'] = response.get('tokens', 0)
            return decision
        except Exception as e:
            logger.error(f"Claude brain error: {e}")
            return self._fallback_decision(course_data, partants, ml_predictions, bankroll)

    def _build_decision_prompt(
        self,
        course: Dict,
        partants: List[Dict],
        ml_preds: List[Dict],
        bankroll: float,
        memory: Dict,
        history: List[Dict],
    ) -> str:

        # Formater les partants avec ML
        partants_str = []
        for p in partants:
            ml = next((x for x in ml_preds if x.get('num_pmu') == p.get('num_pmu')), {})
            prob = ml.get('prob_pct', '?')
            cote = p.get('cote_depart', '?')
            edge = compute_edge(ml.get('prob_top4', 0), float(cote) if cote and cote != '?' else 10) if cote != '?' else 0
            ferrure = p.get('ferrure', '')
            avis = p.get('avis_entraineur', '')
            partants_str.append(
                f"  N°{p.get('num_pmu')} {p.get('nom','?')}"
                f" | Musique: {p.get('musique','?')}"
                f" | Prob ML top4: {prob}%"
                f" | Cote PMU: {cote}"
                f" | Edge: {edge*100:+.1f}%" if cote != '?' else f" | Edge: N/A"
                + (f" | Ferrure: {ferrure} 🔑" if ferrure and 'D4' in str(ferrure).upper() else "")
                + (f" | Avis entr: {avis}" if avis else "")
            )

        # Derniers résultats
        recent_str = []
        for h in history[:10]:
            if h.get('decision') == 'JOUER':
                icon = "✅" if h.get('success') else "❌"
                recent_str.append(
                    f"  {icon} {h.get('course_name','?')} | Joué: N°{h.get('pick1_num')}&{h.get('pick2_num')}"
                    f" | Mise: {h.get('mise_recommandee',0):.1f}€"
                    f" | Résultat: {h.get('gain_perte',0):+.1f}€"
                )
            else:
                recent_str.append(f"  ⏭️ PASSÉ: {h.get('course_name','?')} — {h.get('raison_passer','?')[:60]}")

        # Leçons apprises
        lessons = memory.get('lessons', [])
        lessons_str = "\n".join(f"  • {l}" for l in lessons[-5:]) if lessons else "  Aucune leçon encore"

        # Stats globales
        stats_str = (
            f"Win rate: {memory.get('win_rate',0)*100:.1f}% | "
            f"ROI: {memory.get('roi',0)*100:.1f}% | "
            f"Courses jouées: {memory.get('total_jouees',0)} | "
            f"Passées: {memory.get('total_passees',0)}"
        )

        # Conditions course
        pen = course.get('penetrometre', 0)
        terrain_label = "Bon" if pen <= 2.5 else "Souple" if pen <= 3.8 else "Lourd"
        is_borely = 'bor' in str(course.get('hippodrome', '')).lower()

        prompt = f"""Tu es TURF IA — un expert en pronostics hippiques qui prend des décisions de paris SANS ÉMOTION, uniquement basées sur les données et la rentabilité à long terme.

## COURSE À ANALYSER

**{course.get('course_name', course.get('libelle', 'Cours inconnue'))}**
- Hippodrome: {course.get('hippodrome', '?')}{' ⚠️ BORELY (hippodrome piégeur, taux Da élevé)' if is_borely else ''}
- Discipline: {course.get('discipline', '?')} | Distance: {course.get('distance', '?')}m
- Terrain: {terrain_label} (pénétromètre: {pen})
- Partants: {len(partants)}

## PARTANTS + PROBABILITÉS ML

{chr(10).join(partants_str) if partants_str else "Données non disponibles"}

## BANKROLL & KELLY

- Bankroll actuelle: **{bankroll:.2f}€**
- Mise max autorisée (5%): **{bankroll * MAX_BET_PCT:.2f}€**
- Mise min avec edge ≥10%: Kelly fractionné 25%

## TES PERFORMANCES RÉCENTES

{chr(10).join(recent_str) if recent_str else "  Aucun historique"}

Global: {stats_str}

## CE QUE TU AS APPRIS (MÉMOIRE STRATÉGIQUE)

{lessons_str}

## RÈGLES ABSOLUES

1. Ne jamais jouer si edge < 10% (pas de value)
2. Ne jamais jouer si ≥2 chevaux ont Da récent dans le top 3 ML
3. Ne jamais jouer à Borély si les 2 picks ont Da dans la musique
4. Ne jamais jouer sur des débutants sans forme
5. Kelly pur: si la mise calculée < 2€, ne pas jouer
6. Préférer PASSER si la course est trop incertaine (>6 chevaux avec prob similaire)
7. Discipline de fer: un émotion = une erreur

## TA DÉCISION

Analyse chaque cheval méthodiquement. Identifie les value bets. Calcule le Kelly.
Puis prends ta décision finale.

Réponds UNIQUEMENT en JSON valide:
{{
  "decision": "JOUER" ou "PASSER",
  "raison_passer": "Explication si PASSER (null si JOUER)",
  "pick1_num": null ou numéro,
  "pick1_name": null ou nom,
  "pick1_prob_estime": null ou float (0-1),
  "pick2_num": null ou numéro,
  "pick2_name": null ou nom,
  "pick2_prob_estime": null ou float (0-1),
  "type_pari": null ou "COUPLE_GAGNANT" ou "TIERCE_DESORDRE" ou "QUARTE_DESORDRE",
  "cote_combinee_estimee": null ou float,
  "edge_estime": null ou float (ex: 0.15 = 15%),
  "mise_recommandee": null ou float (en euros, 0 si PASSER),
  "kelly_fraction_utilisee": {KELLY_FRACTION},
  "raisonnement": "Explication complète en français (5-8 phrases), méthodique, sans émotion. Explique POURQUOI chaque cheval, l'edge, et le Kelly.",
  "confiance": float (0-1),
  "signaux_positifs": ["liste des signaux qui confirment"],
  "signaux_negatifs": ["liste des signaux qui inquiètent"],
  "lecon_potentielle": "Ce que cette course pourrait t'apprendre",
  "alerte": null ou "Message d'alerte si risque élevé"
}}"""

        return prompt

    async def _call_claude(self, prompt: str) -> Dict:
        """Appel API Anthropic"""
        r = await self.client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json={
                "model": self.model,
                "max_tokens": 1500,
                "temperature": 0.1,  # Très bas = moins d'aléatoire, plus de cohérence
                "messages": [{"role": "user", "content": prompt}]
            }
        )
        data = r.json()
        raw_text = data.get("content", [{}])[0].get("text", "")
        tokens = data.get("usage", {}).get("output_tokens", 0)
        return {"raw_text": raw_text, "tokens": tokens}

    def _parse_decision(self, response: Dict, bankroll: float,
                        ml_preds: List[Dict], course: Dict) -> Dict:
        """Parse la réponse JSON de Claude"""
        raw = response.get("raw_text", "")
        try:
            # Nettoyer le JSON
            clean = raw.replace("```json", "").replace("```", "").strip()
            # Trouver le JSON dans la réponse
            start = clean.find('{')
            end = clean.rfind('}') + 1
            if start >= 0 and end > start:
                clean = clean[start:end]
            d = json.loads(clean)
        except Exception as e:
            logger.error(f"Parse error: {e}\nRaw: {raw[:500]}")
            return self._fallback_decision(course, [], ml_preds, bankroll)

        # Valider et calculer Kelly si nécessaire
        decision = d.get("decision", "PASSER")
        mise = float(d.get("mise_recommandee") or 0)

        if decision == "JOUER":
            # Recalculer Kelly pour vérification
            prob1 = float(d.get("pick1_prob_estime") or 0)
            prob2 = float(d.get("pick2_prob_estime") or 0)
            cote = float(d.get("cote_combinee_estimee") or 3.0)
            prob_combo = prob1 * prob2 * 2  # Approximation couplé
            kelly_mise = kelly_criterion(min(prob_combo, 0.9), cote, bankroll)

            # Si Claude a calculé une mise, on prend le min entre Claude et Kelly
            if mise > 0 and kelly_mise > 0:
                mise = min(mise, kelly_mise, bankroll * MAX_BET_PCT)
            elif kelly_mise > 0:
                mise = kelly_mise
            else:
                decision = "PASSER"
                d['raison_passer'] = "Kelly = 0 — pas assez d'edge pour rentabiliser"
                mise = 0

        return {
            "decision": decision,
            "raison_passer": d.get("raison_passer"),
            "pick1_num": d.get("pick1_num"),
            "pick1_name": d.get("pick1_name"),
            "pick1_prob": float(d.get("pick1_prob_estime") or 0),
            "pick2_num": d.get("pick2_num"),
            "pick2_name": d.get("pick2_name"),
            "pick2_prob": float(d.get("pick2_prob_estime") or 0),
            "type_pari": d.get("type_pari", "COUPLE_GAGNANT"),
            "cote_estimee": float(d.get("cote_combinee_estimee") or 3.0),
            "edge_estime": float(d.get("edge_estime") or 0),
            "mise_recommandee": round(mise, 2),
            "kelly_fraction": KELLY_FRACTION,
            "raisonnement": d.get("raisonnement", ""),
            "confiance": float(d.get("confiance") or 0),
            "signaux_positifs": d.get("signaux_positifs", []),
            "signaux_negatifs": d.get("signaux_negatifs", []),
            "lecon_potentielle": d.get("lecon_potentielle", ""),
            "alerte": d.get("alerte"),
        }

    def _fallback_decision(self, course: Dict, partants: List,
                           ml_preds: List[Dict], bankroll: float) -> Dict:
        """Décision de secours si pas de clé API"""
        if not ml_preds:
            return {"decision": "PASSER", "raison_passer": "Pas de données ML disponibles",
                    "mise_recommandee": 0, "raisonnement": "Mode fallback — API Claude non disponible"}
        top2 = ml_preds[:2]
        p1_prob = top2[0].get('prob_top4', 0.3) if top2 else 0
        p2_prob = top2[1].get('prob_top4', 0.2) if len(top2) > 1 else 0
        kelly_mise = kelly_criterion(p1_prob * p2_prob * 2, 3.5, bankroll)
        return {
            "decision": "JOUER" if kelly_mise >= 2 else "PASSER",
            "pick1_num": top2[0].get('num_pmu') if top2 else None,
            "pick1_name": top2[0].get('nom') if top2 else None,
            "pick1_prob": p1_prob,
            "pick2_num": top2[1].get('num_pmu') if len(top2) > 1 else None,
            "pick2_name": top2[1].get('nom') if len(top2) > 1 else None,
            "pick2_prob": p2_prob,
            "type_pari": "COUPLE_GAGNANT",
            "cote_estimee": 3.5,
            "edge_estime": 0.1,
            "mise_recommandee": kelly_mise,
            "kelly_fraction": KELLY_FRACTION,
            "raisonnement": "Décision automatique ML (API Claude non disponible)",
            "confiance": 0.4,
            "signaux_positifs": [], "signaux_negatifs": [],
            "lecon_potentielle": "", "alerte": "API Claude manquante",
            "raison_passer": None,
        }

    # ================================================================
    # APPRENTISSAGE — Après résultat connu
    # ================================================================

    async def learn_from_result(
        self,
        decision: Dict,
        result: Dict,
        memory: Dict,
        stats: Dict,
    ) -> Dict:
        """
        Claude analyse son erreur ou succès et met à jour sa stratégie.
        Appelé après chaque résultat connu.
        """
        if not self.api_key:
            return memory

        success = result.get('success', False)
        top4 = result.get('top4', [])
        gain = result.get('gain_perte', 0)

        prompt = f"""Tu es TURF IA. Tu viens de recevoir le résultat d'une course sur laquelle tu as pris une décision.

## TA DÉCISION

Course: {decision.get('course_name', '?')}
Décision: {decision.get('decision', '?')}
Picks: N°{decision.get('pick1_num')} {decision.get('pick1_name')} & N°{decision.get('pick2_num')} {decision.get('pick2_name')}
Mise: {decision.get('mise_recommandee', 0):.2f}€
Ton raisonnement: {decision.get('raisonnement', '')[:300]}

## RÉSULTAT RÉEL

Arrivée définitive: {' – '.join(map(str, top4[:4]))}
Résultat: {'✅ SUCCÈS — 2 chevaux dans le top 4' if success else '❌ ÉCHEC'}
Gain/Perte: {gain:+.2f}€

## TA MÉMOIRE ACTUELLE

Leçons apprises: {json.dumps(memory.get('lessons', [])[-5:], ensure_ascii=False)}
Patterns d'erreur: {json.dumps(memory.get('pattern_errors', [])[-3:], ensure_ascii=False)}

## STATS GLOBALES

Win rate: {stats.get('win_rate', 0)}% | ROI: {stats.get('roi', 0)}% | Total jouées: {stats.get('jouees', 0)}

## ANALYSE POST-COURSE

{"**BONNE DÉCISION** — Analyse pourquoi ça a marché et ce qu'on peut renforcer." if success else "**MAUVAISE DÉCISION** — Analyse honnêtement l'erreur. Qu'est-ce que tu n'as pas vu ? Comment éviter ça la prochaine fois ?"}

Réponds en JSON:
{{
  "nouvelle_lecon": "Leçon concrète et actionnable apprise (1 phrase)",
  "pattern_erreur": {"si échec": "Pattern identifié (ex: 'Da récent ignoré en plat souple')", "si succès": null},
  "ajustement_strategie": "Ajustement concret à faire (ex: 'Augmenter le seuil edge à 12% sur Borély')",
  "auto_critique": "Évaluation honnête de la décision sur 10 et pourquoi",
  "confiance_ajustee": float
}}"""

        try:
            response = await self._call_claude(prompt)
            raw = response.get("raw_text", "")
            clean = raw.replace("```json", "").replace("```", "").strip()
            start = clean.find('{'); end = clean.rfind('}') + 1
            if start >= 0 and end > start:
                learning = json.loads(clean[start:end])

                # Mettre à jour la mémoire
                lessons = memory.get('lessons', [])
                if learning.get('nouvelle_lecon'):
                    lessons.append(learning['nouvelle_lecon'])
                    lessons = lessons[-20:]  # Garder les 20 dernières

                errors = memory.get('pattern_errors', [])
                if learning.get('pattern_erreur') and not success:
                    errors.append(learning['pattern_erreur'])
                    errors = errors[-10:]

                memory['lessons'] = lessons
                memory['pattern_errors'] = errors
                memory['last_learning'] = learning
                return memory
        except Exception as e:
            logger.error(f"Learning error: {e}")

        return memory

    # ================================================================
    # ANALYSE MATINALE
    # ================================================================

    async def morning_briefing(self, stats: Dict, history: List[Dict], memory: Dict) -> str:
        """Analyse stratégique complète du matin"""
        if not self.api_key:
            return f"📊 Stats: {stats.get('win_rate',0)}% win rate | ROI: {stats.get('roi',0)}%"

        recent_gains = [h.get('gain_perte', 0) for h in history[:20] if h.get('status') == 'completed']
        streak = 0
        for h in history:
            if h.get('status') != 'completed': break
            if h.get('success'): streak += 1
            else: break

        prompt = f"""Tu es TURF IA. Fais le bilan stratégique matinal et donne des recommandations pour aujourd'hui.

## PERFORMANCE GLOBALE

Win rate: {stats.get('win_rate',0)}%
ROI: {stats.get('roi',0)}%
Bankroll: {stats.get('bankroll_actuelle',0):.2f}€ (initiale: {stats.get('bankroll_initiale',0):.2f}€)
Série en cours: {streak} victoires consécutives
Gains récents (20 dernières): {sum(recent_gains):+.2f}€

## LEÇONS APPRISES

{json.dumps(memory.get('lessons', [])[-8:], ensure_ascii=False)}

## PATTERNS D'ERREUR IDENTIFIÉS

{json.dumps(memory.get('pattern_errors', [])[-5:], ensure_ascii=False)}

Fais un bilan en 4-5 phrases: ce qui marche, ce qui ne marche pas, et les ajustements pour aujourd'hui. Sois direct et sans complaisance."""

        try:
            response = await self._call_claude(prompt)
            return response.get("raw_text", "Analyse non disponible")
        except:
            return f"Bankroll: {stats.get('bankroll_actuelle',0):.2f}€ | Win rate: {stats.get('win_rate',0)}%"


brain = ClaudeBrain()
