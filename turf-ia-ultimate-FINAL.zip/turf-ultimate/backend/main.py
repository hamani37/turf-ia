"""TURF IA ULTIMATE — FastAPI + Claude Brain"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio, logging, os
from datetime import datetime

from database import db
from pmu_client import pmu, scoring
from claude_brain import brain
from telegram_bot import telegram

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await db.init()
    asyncio.create_task(_startup())
    yield

app = FastAPI(title="TURF IA Ultimate", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

async def _startup():
    await asyncio.sleep(3)
    stats = await db.get_stats()
    await telegram.send_startup(stats)


# ── HEALTH ─────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "version": "ultimate", "timestamp": datetime.now().isoformat()}


# ── PROGRAMME ──────────────────────────────────────────────────
@app.get("/api/programme/{date_str}")
async def get_programme(date_str: str):
    data = await pmu.get_programme(date_str)
    if not data: raise HTTPException(404, "Programme non trouvé")
    return data


# ── DÉCISION PRINCIPALE ────────────────────────────────────────
@app.post("/api/decide")
async def decide_course(payload: dict):
    """
    Point d'entrée principal.
    Claude analyse la course et prend la décision complète.
    """
    date_str = payload.get("date")
    reunion = payload.get("reunion")
    course_num = payload.get("course_num")
    course_info = payload.get("course", {})

    # Charger les partants
    partants = await pmu.get_partants(date_str, reunion, course_num)
    if not partants:
        raise HTTPException(404, "Partants non trouvés")

    # Scores ML
    ml_preds = scoring.score_all(partants, course_info)

    # Bankroll actuelle
    bankroll = await db.get_bankroll()

    # Mémoire stratégique
    memory = await db.get_strategy_memory()

    # Historique récent
    history = await db.get_history(limit=20)

    # ── CLAUDE DÉCIDE ──────────────────────────────────────────
    decision = await brain.decide(
        course_data={**course_info, "course_name": course_info.get("libelle", f"R{reunion}C{course_num}"),
                     "hippodrome": course_info.get("hippodrome", {}).get("libelle", "?") if isinstance(course_info.get("hippodrome"), dict) else str(course_info.get("hippodrome", "?"))},
        partants=partants,
        ml_predictions=ml_preds,
        bankroll=bankroll,
        strategy_memory=memory,
        recent_history=history,
    )

    # Sauvegarder
    dec_data = {
        **decision,
        "date": date_str, "reunion": reunion, "course_num": course_num,
        "course_name": course_info.get("libelle", f"R{reunion}C{course_num}"),
        "discipline": course_info.get("discipline"),
        "distance": course_info.get("distance"),
        "hippodrome": course_info.get("hippodrome", {}).get("libelle", "?") if isinstance(course_info.get("hippodrome"), dict) else "?",
        "bankroll_au_moment": bankroll,
        "model_data": {"ml_top3": ml_preds[:3]},
    }
    dec_id = await db.save_decision(dec_data)

    # Sauvegarder le thinking Claude
    if decision.get('_prompt'):
        await db.save_ai_thinking(dec_id, decision['_prompt'],
                                   decision.get('_raw_response', ''),
                                   decision.get('_tokens', 0))

    # Notification Telegram
    await telegram.send_decision(decision, bankroll)

    # Retourner sans les champs internes
    clean_dec = {k: v for k, v in decision.items() if not k.startswith('_')}
    return {
        "decision_id": dec_id,
        "decision": clean_dec,
        "ml_predictions": ml_preds,
        "bankroll": bankroll,
    }


# ── CHECK RÉSULTATS ────────────────────────────────────────────
@app.get("/api/check-results")
async def check_results_now():
    from scripts.check_results import run_check
    return await run_check()


# ── STATS & DASHBOARD ──────────────────────────────────────────
@app.get("/api/stats")
async def get_stats():
    return await db.get_stats()

@app.get("/api/history")
async def get_history(limit: int = 50):
    return await db.get_history(limit)

@app.get("/api/bankroll")
async def get_bankroll_history():
    return await db.get_bankroll_history(limit=100)

@app.get("/api/memory")
async def get_memory():
    return await db.get_strategy_memory()

@app.post("/api/bankroll/adjust")
async def adjust_bankroll(payload: dict):
    """Ajustement manuel de la bankroll"""
    amount = float(payload.get("amount", 0))
    motif = payload.get("motif", "Ajustement manuel")
    if amount == 0: raise HTTPException(400, "Montant requis")
    new_val = await db.update_bankroll(amount, motif)
    return {"bankroll": new_val, "variation": amount}

@app.post("/api/telegram/test")
async def test_telegram():
    ok = await telegram.send("🤖 TURF IA Ultimate — Test connexion OK !")
    return {"success": ok}
