"""PMU Client + Scoring ML simplifié"""
import httpx, re, math, logging
from typing import Dict, List, Optional
from tenacity import retry, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)
PMU_BASE = "https://online.turfinfo.api.pmu.fr/rest/client/1"

class PMUClient:
    def __init__(self):
        self.client = httpx.AsyncClient(
            timeout=30.0, headers={"User-Agent": "Mozilla/5.0 (compatible; TurfIA)"}
        )

    def _fmt(self, d: str) -> str:
        y,m,dd = d.split("-"); return f"{dd}{m}{y}"

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
    async def _get(self, url: str) -> Optional[Dict]:
        try:
            r = await self.client.get(url)
            if r.status_code == 404: return None
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.warning(f"PMU: {url} — {e}"); raise

    async def get_programme(self, date: str) -> Dict:
        return await self._get(f"{PMU_BASE}/programme/{self._fmt(date)}") or {}

    async def get_partants(self, date: str, r: int, c: int) -> List[Dict]:
        data = await self._get(f"{PMU_BASE}/programme/{self._fmt(date)}/R{r}/C{c}/participants") or {}
        raw = data.get("participants", [])
        return [self._parse(p) for p in raw]

    async def get_arrivee(self, date: str, r: int, c: int) -> Optional[Dict]:
        data = await self._get(f"{PMU_BASE}/programme/{self._fmt(date)}/R{r}/C{c}/rapports-definitifs")
        if not data: return None
        top4 = []
        for rap in data.get("rapportsDefinitifs", []):
            comb = rap.get("combinaisonGagnante")
            if comb and isinstance(comb, list) and len(comb) >= 2:
                top4 = [int(x) for x in comb[:4] if str(x).isdigit()]; break
        if not top4:
            arr = data.get("arrivee", [])
            if arr: top4 = [int(x.get("numPmu",0)) for x in arr[:4] if x.get("numPmu")]
        return {"definitive": bool(data.get("rapportsDefinitifs")), "top4": top4}

    def _parse(self, p: Dict) -> Dict:
        gains = p.get("gainsCarriere", {})
        g = gains.get("gainsCarriere", 0) if isinstance(gains, dict) else gains or 0
        drv = p.get("driver", {}) or {}; jock = p.get("jockey", {}) or {}
        entr = p.get("entraineur", {}) or {}
        cote = p.get("dernierRapportDirect", {})
        return {
            "num_pmu": p.get("numPmu"),
            "nom": p.get("nom"),
            "driver": drv.get("nom") or jock.get("nom"),
            "entraineur": entr.get("nom"),
            "musique": p.get("musique"),
            "gains_carriere": float(g or 0),
            "poids": p.get("handicapValeur") or p.get("poidsConditionMonte"),
            "ferrure": p.get("ferrure") or p.get("deferre"),
            "avis_entraineur": p.get("avisEntraineur"),
            "cote_depart": cote.get("rapport") if isinstance(cote, dict) else None,
        }


class ScoringEngine:
    """Scoring ML simplifié pour préparer les données pour Claude"""

    def score_all(self, partants: List[Dict], course: Dict) -> List[Dict]:
        disc = (course.get("discipline") or "").upper()
        is_obstacle = disc in ["HAIES", "STEEPLE_CHASE", "OBSTACLE"]
        is_plat = disc == "PLAT"
        pen = float(course.get("penetrometre") or 0)
        hippo = str(course.get("hippodrome") or "").lower()
        is_borely = "bor" in hippo

        results = []
        for p in partants:
            score = self._score(p, is_obstacle, is_plat, pen, is_borely)
            results.append({
                "num_pmu": p.get("num_pmu"),
                "nom": p.get("nom", "?"),
                "score": score,
                "prob_top4": 0,
                "prob_pct": 0,
            })

        # Normaliser en probabilités via softmax
        import numpy as np
        scores = np.array([r["score"] for r in results], dtype=float)
        scores = scores - scores.max()
        exp_s = np.exp(scores * 0.3)
        probs = exp_s / exp_s.sum()

        for r, prob in zip(results, probs):
            r["prob_top4"] = float(prob)
            r["prob_pct"] = round(float(prob) * 100, 1)
            r["fair_odds"] = round(1 / max(float(prob), 0.01), 1)

        return sorted(results, key=lambda x: x["prob_top4"], reverse=True)

    def _score(self, p: Dict, is_obstacle: bool, is_plat: bool, pen: float, is_borely: bool) -> float:
        musique = p.get("musique") or ""
        tokens = re.findall(r'[0-9]+[a-zA-Z]*|[A-Za-z]+', musique)
        last3 = tokens[-3:] if len(tokens) >= 3 else tokens
        score = 0.0
        for i, t in enumerate(last3):
            w = 3 if i == len(last3)-1 else 2 if i == len(last3)-2 else 1
            is_da = bool(re.match(r'^[DdJjHhTt]', t, re.I))
            n = int(re.match(r'^(\d+)', t).group(1)) if re.match(r'^(\d+)', t) else -1
            if is_da:
                score += (-1 if is_obstacle else -3) * w
                if is_borely: score -= 2 * w
            elif n == 1: score += 10 * w
            elif n == 2: score += 7 * w
            elif n == 3: score += 5 * w
            elif 4 <= n <= 5: score += 3 * w
            elif n == 0: score -= 1 * w
            else: score -= 0.5 * w

        ferrure = (p.get("ferrure") or "").upper()
        if "D4" in ferrure: score += 12
        elif "DP" in ferrure: score += 4

        if is_plat:
            poids = float(p.get("poids") or 58)
            if poids <= 53: score += 10
            elif poids <= 56: score += 6

        avis = (p.get("avis_entraineur") or "").upper()
        if avis in ["POSITIF", "TRES_POSITIF"]: score += 4
        elif avis == "NEGATIF": score -= 3

        g = float(p.get("gains_carriere") or 0)
        if g > 100000: g /= 100
        if g > 50000: score += 3
        elif g > 20000: score += 2

        return max(0, score)


pmu = PMUClient()
scoring = ScoringEngine()
