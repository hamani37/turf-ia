"""Database — PostgreSQL Neon.tech"""
import os, json, logging
from typing import List, Dict, Optional
import asyncpg

logger = logging.getLogger(__name__)

class Database:
    def __init__(self):
        self.pool = None

    async def init(self):
        self.pool = await asyncpg.create_pool(
            os.getenv("DATABASE_URL"), min_size=2, max_size=10, ssl="require"
        )
        await self._create_tables()
        await self._init_bankroll()
        logger.info("✅ DB initialisée")

    async def _create_tables(self):
        async with self.pool.acquire() as c:
            await c.execute("""
            CREATE TABLE IF NOT EXISTS decisions (
                id SERIAL PRIMARY KEY,
                date DATE NOT NULL,
                reunion INT,
                course_num INT,
                course_name TEXT,
                discipline TEXT,
                distance INT,
                hippodrome TEXT,
                -- Décision Claude
                decision TEXT NOT NULL,        -- 'JOUER' ou 'PASSER'
                raison_passer TEXT,            -- Si PASSER : pourquoi
                pick1_num INT,
                pick1_name TEXT,
                pick1_prob FLOAT,
                pick2_num INT,
                pick2_name TEXT,
                pick2_prob FLOAT,
                type_pari TEXT,                -- 'COUPLE_GAGNANT','TIERCE','QUARTE'
                mise_recommandee FLOAT,        -- En euros
                edge_estime FLOAT,             -- Edge % estimé
                cote_estimee FLOAT,
                raisonnement TEXT,             -- Explication complète Claude
                -- Kelly
                kelly_fraction FLOAT,
                bankroll_au_moment FLOAT,
                -- Résultat
                real_result JSONB,
                pick1_in_top4 BOOLEAN,
                pick2_in_top4 BOOLEAN,
                success BOOLEAN,
                gain_perte FLOAT DEFAULT 0,
                status TEXT DEFAULT 'pending',
                -- Meta
                model_data JSONB,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(date, reunion, course_num)
            );

            CREATE TABLE IF NOT EXISTS bankroll (
                id SERIAL PRIMARY KEY,
                montant FLOAT NOT NULL,
                variation FLOAT DEFAULT 0,
                motif TEXT,
                decision_id INT REFERENCES decisions(id),
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            CREATE TABLE IF NOT EXISTS strategy_memory (
                id SERIAL PRIMARY KEY,
                version INT DEFAULT 1,
                -- Ce que Claude a appris
                lessons JSONB DEFAULT '[]',
                pattern_errors JSONB DEFAULT '[]',
                adjustments JSONB DEFAULT '{}',
                -- Stats par contexte
                stats_by_discipline JSONB DEFAULT '{}',
                stats_by_hippodrome JSONB DEFAULT '{}',
                stats_by_terrain JSONB DEFAULT '{}',
                -- Méta
                total_decisions INT DEFAULT 0,
                total_jouees INT DEFAULT 0,
                total_passees INT DEFAULT 0,
                win_rate FLOAT DEFAULT 0,
                roi FLOAT DEFAULT 0,
                updated_at TIMESTAMPTZ DEFAULT NOW()
            );

            CREATE TABLE IF NOT EXISTS ai_thinking (
                id SERIAL PRIMARY KEY,
                decision_id INT REFERENCES decisions(id),
                prompt_used TEXT,
                raw_response TEXT,
                tokens_used INT,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            CREATE INDEX IF NOT EXISTS idx_dec_date ON decisions(date);
            CREATE INDEX IF NOT EXISTS idx_dec_status ON decisions(status);
            CREATE INDEX IF NOT EXISTS idx_bank_date ON bankroll(created_at);
            """)

    async def _init_bankroll(self):
        async with self.pool.acquire() as c:
            n = await c.fetchval("SELECT COUNT(*) FROM bankroll")
            if n == 0:
                initial = float(os.getenv("BANKROLL_INITIAL", "500"))
                await c.execute(
                    "INSERT INTO bankroll(montant, motif) VALUES($1, 'Bankroll initiale')",
                    initial
                )
            n2 = await c.fetchval("SELECT COUNT(*) FROM strategy_memory")
            if n2 == 0:
                await c.execute("INSERT INTO strategy_memory DEFAULT VALUES")

    # ── BANKROLL ────────────────────────────────────────────────

    async def get_bankroll(self) -> float:
        async with self.pool.acquire() as c:
            row = await c.fetchrow("SELECT montant FROM bankroll ORDER BY id DESC LIMIT 1")
            return float(row['montant']) if row else 500.0

    async def update_bankroll(self, variation: float, motif: str, decision_id: int = None):
        async with self.pool.acquire() as c:
            current = await self.get_bankroll()
            new_val = current + variation
            await c.execute(
                "INSERT INTO bankroll(montant, variation, motif, decision_id) VALUES($1,$2,$3,$4)",
                new_val, variation, motif, decision_id
            )
        return new_val

    async def get_bankroll_history(self, limit=50) -> List[Dict]:
        async with self.pool.acquire() as c:
            rows = await c.fetch(
                "SELECT montant, variation, motif, created_at FROM bankroll ORDER BY id DESC LIMIT $1",
                limit
            )
            return [dict(r) for r in rows]

    # ── DECISIONS ───────────────────────────────────────────────

    async def save_decision(self, d: Dict) -> int:
        async with self.pool.acquire() as c:
            row = await c.fetchrow("""
                INSERT INTO decisions(
                    date, reunion, course_num, course_name, discipline, distance, hippodrome,
                    decision, raison_passer, pick1_num, pick1_name, pick1_prob,
                    pick2_num, pick2_name, pick2_prob, type_pari, mise_recommandee,
                    edge_estime, cote_estimee, raisonnement, kelly_fraction,
                    bankroll_au_moment, model_data, status
                ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,'pending')
                ON CONFLICT(date,reunion,course_num) DO UPDATE SET
                    decision=EXCLUDED.decision,
                    raisonnement=EXCLUDED.raisonnement,
                    mise_recommandee=EXCLUDED.mise_recommandee,
                    updated_at=NOW()
                RETURNING id
            """,
                d.get('date'), d.get('reunion'), d.get('course_num'),
                d.get('course_name'), d.get('discipline'), d.get('distance'), d.get('hippodrome'),
                d.get('decision'), d.get('raison_passer'),
                d.get('pick1_num'), d.get('pick1_name'), d.get('pick1_prob'),
                d.get('pick2_num'), d.get('pick2_name'), d.get('pick2_prob'),
                d.get('type_pari'), d.get('mise_recommandee'),
                d.get('edge_estime'), d.get('cote_estimee'),
                d.get('raisonnement'), d.get('kelly_fraction'),
                d.get('bankroll_au_moment'),
                json.dumps(d.get('model_data', {}))
            )
            return row['id']

    async def save_ai_thinking(self, decision_id: int, prompt: str, response: str, tokens: int):
        async with self.pool.acquire() as c:
            await c.execute(
                "INSERT INTO ai_thinking(decision_id, prompt_used, raw_response, tokens_used) VALUES($1,$2,$3,$4)",
                decision_id, prompt, response, tokens
            )

    async def get_pending_decisions(self) -> List[Dict]:
        async with self.pool.acquire() as c:
            rows = await c.fetch(
                "SELECT * FROM decisions WHERE status='pending' AND decision='JOUER' ORDER BY date ASC"
            )
            return [dict(r) for r in rows]

    async def update_decision_result(self, dec_id: int, top4: List[int], gain_perte: float):
        async with self.pool.acquire() as c:
            dec = await c.fetchrow("SELECT pick1_num, pick2_num FROM decisions WHERE id=$1", dec_id)
            p1 = dec['pick1_num'] in top4 if dec else False
            p2 = dec['pick2_num'] in top4 if dec else False
            await c.execute("""
                UPDATE decisions SET
                    real_result=$1, pick1_in_top4=$2, pick2_in_top4=$3,
                    success=$4, gain_perte=$5, status='completed', updated_at=NOW()
                WHERE id=$6
            """, json.dumps(top4), p1, p2, bool(p1 and p2), gain_perte, dec_id)

    async def get_history(self, limit=50) -> List[Dict]:
        async with self.pool.acquire() as c:
            rows = await c.fetch("""
                SELECT id, date, course_name, discipline, hippodrome,
                    decision, pick1_num, pick1_name, pick1_prob,
                    pick2_num, pick2_name, pick2_prob,
                    type_pari, mise_recommandee, edge_estime,
                    real_result, success, gain_perte, status,
                    raisonnement, raison_passer, kelly_fraction, bankroll_au_moment
                FROM decisions ORDER BY date DESC, id DESC LIMIT $1
            """, limit)
            result = []
            for r in rows:
                d = dict(r)
                if d.get('real_result'):
                    try: d['real_result'] = json.loads(d['real_result'])
                    except: pass
                result.append(d)
            return result

    async def get_stats(self) -> Dict:
        async with self.pool.acquire() as c:
            total = await c.fetchval("SELECT COUNT(*) FROM decisions WHERE status='completed'")
            jouees = await c.fetchval("SELECT COUNT(*) FROM decisions WHERE decision='JOUER' AND status='completed'")
            passees = await c.fetchval("SELECT COUNT(*) FROM decisions WHERE decision='PASSER' AND status='completed'")
            wins = await c.fetchval("SELECT COUNT(*) FROM decisions WHERE success=TRUE AND status='completed'")
            total_gain = await c.fetchval("SELECT COALESCE(SUM(gain_perte),0) FROM decisions WHERE status='completed'")
            bankroll = await self.get_bankroll()
            initial = float(os.getenv("BANKROLL_INITIAL", "500"))

            # Par discipline
            by_disc = await c.fetch("""
                SELECT discipline,
                    COUNT(*) FILTER(WHERE decision='JOUER') as jouees,
                    COUNT(*) FILTER(WHERE success=TRUE) as wins
                FROM decisions WHERE status='completed' GROUP BY discipline
            """)

            # Evolution bankroll 30 jours
            bank_history = await c.fetch("""
                SELECT DATE(created_at) as d, montant
                FROM bankroll
                WHERE created_at >= NOW() - INTERVAL '30 days'
                ORDER BY id
            """)

            return {
                "total": total or 0,
                "jouees": jouees or 0,
                "passees": passees or 0,
                "wins": wins or 0,
                "win_rate": round((wins or 0) / (jouees or 1) * 100),
                "total_gain": float(total_gain or 0),
                "roi": round(float(total_gain or 0) / initial * 100, 1),
                "bankroll_actuelle": bankroll,
                "bankroll_initiale": initial,
                "by_discipline": [dict(r) for r in by_disc],
                "bank_history": [dict(r) for r in bank_history],
            }

    # ── STRATEGY MEMORY ─────────────────────────────────────────

    async def get_strategy_memory(self) -> Dict:
        async with self.pool.acquire() as c:
            row = await c.fetchrow("SELECT * FROM strategy_memory ORDER BY id DESC LIMIT 1")
            if not row: return {}
            d = dict(row)
            for k in ['lessons','pattern_errors','adjustments','stats_by_discipline','stats_by_hippodrome','stats_by_terrain']:
                if d.get(k):
                    try: d[k] = json.loads(d[k]) if isinstance(d[k], str) else d[k]
                    except: pass
            return d

    async def update_strategy_memory(self, updates: Dict):
        async with self.pool.acquire() as c:
            for k, v in updates.items():
                if isinstance(v, (dict, list)):
                    v = json.dumps(v)
                await c.execute(
                    f"UPDATE strategy_memory SET {k}=$1, updated_at=NOW()",
                    v
                )

db = Database()
