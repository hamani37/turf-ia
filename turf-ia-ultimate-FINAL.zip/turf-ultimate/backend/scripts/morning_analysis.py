"""Briefing matinal Claude"""
import asyncio, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from database import db
from claude_brain import brain
from telegram_bot import telegram

async def main():
    await db.init()
    stats = await db.get_stats()
    history = await db.get_history(30)
    memory = await db.get_strategy_memory()
    briefing = await brain.morning_briefing(stats, history, memory)
    await telegram.send_morning(briefing, stats)
    await db.pool.close()

if __name__ == "__main__":
    asyncio.run(main())
