"""Vérification arrivées PMU + apprentissage Claude"""
import asyncio, sys, os, logging, json
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from database import db
from pmu_client import pmu
from claude_brain import brain
from telegram_bot import telegram

logger = logging.getLogger(__name__)


async def run_check() -> dict:
    pending = await db.get_pending_decisions()
    if not pending: return {"updated": 0}
    updated = 0

    for dec in pending:
        try:
            arrivee = await pmu.get_arrivee(str(dec['date']), dec['reunion'], dec['course_num'])
            if not arrivee or not arrivee.get('definitive'): continue
            top4 = arrivee.get('top4', [])
            if not top4: continue

            success = dec['pick1_num'] in top4 and dec['pick2_num'] in top4
            # Gain simplifié : si succès couplé gagnant ≈ mise × 2.5
            mise = float(dec.get('mise_recommandee') or 0)
            gain = mise * 2.5 - mise if success else -mise

            await db.update_decision_result(dec['id'], top4, gain)

            # Mettre à jour la bankroll
            new_bankroll = await db.update_bankroll(gain, f"Course: {dec.get('course_name','?')}", dec['id'])

            # Claude apprend de l'erreur/succès
            memory = await db.get_strategy_memory()
            stats = await db.get_stats()
            updated_memory = await brain.learn_from_result(
                decision={**dec, 'success': success},
                result={"top4": top4, "success": success, "gain_perte": gain},
                memory=memory,
                stats=stats,
            )

            # Sauvegarder la mémoire mise à jour
            if updated_memory.get('lessons'):
                await db.update_strategy_memory({
                    'lessons': updated_memory['lessons'],
                    'pattern_errors': updated_memory.get('pattern_errors', []),
                    'total_jouees': stats.get('jouees', 0) + 1,
                    'win_rate': stats.get('win_rate', 0) / 100,
                    'roi': stats.get('roi', 0) / 100,
                })

            lecon = updated_memory.get('last_learning', {}).get('nouvelle_lecon', '')
            await telegram.send_result(
                {**dec, 'success': success}, top4, gain, new_bankroll, lecon
            )
            updated += 1

        except Exception as e:
            logger.error(f"Error dec {dec.get('id')}: {e}")

    return {"updated": updated}


async def main():
    await db.init()
    result = await run_check()
    print(result)
    await db.pool.close()

if __name__ == "__main__":
    asyncio.run(main())
