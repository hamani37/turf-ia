"""Telegram Bot — Notifications décisions Claude"""
import httpx, os, logging
from typing import Dict, List

logger = logging.getLogger(__name__)

class TelegramBot:
    def __init__(self):
        self.token = os.getenv("TELEGRAM_BOT_TOKEN")
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", "@Hamani37")
        self.client = httpx.AsyncClient(timeout=15.0)

    async def send(self, msg: str) -> bool:
        if not self.token:
            logger.info(f"[TG] {msg[:100]}")
            return True
        try:
            r = await self.client.post(
                f"https://api.telegram.org/bot{self.token}/sendMessage",
                json={"chat_id": self.chat_id, "text": msg,
                      "parse_mode": "Markdown", "disable_web_page_preview": True}
            )
            return r.status_code == 200
        except Exception as e:
            logger.error(f"TG error: {e}"); return False

    async def send_decision(self, d: Dict, bankroll: float):
        """Notification décision principale"""
        if d['decision'] == 'PASSER':
            await self.send(
                f"⏭️ *PASSER — {d.get('course_name','?')}*\n\n"
                f"_{d.get('raison_passer','?')[:200]}_\n\n"
                f"💰 Bankroll: {bankroll:.2f}€"
            )
        else:
            alerte = f"\n⚠️ *ALERTE:* _{d.get('alerte')}_" if d.get('alerte') else ""
            pos_signals = "\n".join(f"  ✓ {s}" for s in d.get('signaux_positifs', [])[:3])
            neg_signals = "\n".join(f"  ✗ {s}" for s in d.get('signaux_negatifs', [])[:2])

            await self.send(
                f"🎯 *JOUER — {d.get('course_name','?')}*{alerte}\n\n"
                f"🥇 N°{d.get('pick1_num')} *{d.get('pick1_name')}* ({d.get('pick1_prob',0)*100:.0f}%)\n"
                f"🥈 N°{d.get('pick2_num')} *{d.get('pick2_name')}* ({d.get('pick2_prob',0)*100:.0f}%)\n\n"
                f"💶 *Mise: {d.get('mise_recommandee',0):.2f}€* | {d.get('type_pari','?')}\n"
                f"📈 Edge estimé: {d.get('edge_estime',0)*100:+.1f}%\n"
                f"💰 Bankroll: {bankroll:.2f}€\n\n"
                f"🧠 *Raisonnement:*\n_{d.get('raisonnement','')[:400]}_\n"
                + (f"\n✅ Signaux+:\n{pos_signals}" if pos_signals else "")
                + (f"\n❌ Signaux-:\n{neg_signals}" if neg_signals else "")
            )

    async def send_result(self, d: Dict, top4: List[int], gain: float, bankroll: float, lecon: str = ""):
        icon = "✅" if d.get('success') else "❌"
        await self.send(
            f"{icon} *RÉSULTAT — {d.get('course_name','?')}*\n\n"
            f"Picks: N°{d.get('pick1_num')} & N°{d.get('pick2_num')}\n"
            f"Arrivée: {' – '.join(map(str, top4[:4]))}\n"
            f"{'✅ 2 picks dans le top 4 !' if d.get('success') else '❌ Pas les bons chevaux'}\n\n"
            f"{'Gain' if gain >= 0 else 'Perte'}: *{gain:+.2f}€*\n"
            f"💰 Bankroll: *{bankroll:.2f}€*"
            + (f"\n\n💡 *Leçon:* _{lecon[:200]}_" if lecon else "")
        )

    async def send_morning(self, briefing: str, stats: Dict):
        await self.send(
            f"🌅 *TURF IA — Briefing matinal*\n\n"
            f"{briefing[:600]}\n\n"
            f"📊 Win rate: *{stats.get('win_rate',0)}%* | ROI: *{stats.get('roi',0)}%*\n"
            f"💰 Bankroll: *{stats.get('bankroll_actuelle',0):.2f}€*"
        )

    async def send_startup(self, stats: Dict):
        await self.send(
            f"🤖 *TURF IA ULTIMATE démarré*\n\n"
            f"🧠 Cerveau: Claude Sonnet\n"
            f"💰 Bankroll: *{stats.get('bankroll_actuelle',0):.2f}€*\n"
            f"📊 {stats.get('total',0)} décisions en base\n"
            f"✅ Win rate: {stats.get('win_rate',0)}% | ROI: {stats.get('roi',0)}%\n\n"
            f"⚡ Système actif — je surveille les courses."
        )


telegram = TelegramBot()
